<?php

class Markdown
{
    public function toHtml($argument1)
    {
        // TODO: write logic here
    }
}
