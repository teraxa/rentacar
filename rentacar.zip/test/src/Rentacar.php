<?php

class Rentacar
{
}
