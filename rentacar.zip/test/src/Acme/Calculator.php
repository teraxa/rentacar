<?php

namespace Acme;

class Calculator
{
}
